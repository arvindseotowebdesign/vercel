function Beforeftr() {
    return (
        <section className="about">
            
            <div className="container mt-5">
                <div className="row">
                    <div className="col-md-3"></div>
                    <div className="col-md-3"></div>
                    <div className="col-md-6 mt-5" >
                        <h3>BRAND ME NOW</h3>
                        <p>shop here a best quality of clothing</p>
                        <button className="btn2"> SHOP NOW
                        </button>
                    </div>

                </div>
            </div>
        </section>
    );
}

export default Beforeftr;